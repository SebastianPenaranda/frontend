import React, { useState, useEffect } from "react";
import axios from "axios";
import Header from "./components/header/Header";

const App = () => {
  const [menu, setMenu] = useState("inicio");
  const [user, setUser] = useState({ username: "", password: "", role: "lector" });
  const [loggedIn, setLoggedIn] = useState(false);
  const [role, setRole] = useState(null);
  const [formData, setFormData] = useState({
    nombre: "",
    apellido: "",
    documento: "",
    telefono: "",
    direccion: "",
    email: "",
    genero: "",
    fecha: "",
    hora: "",
    fingerprint: "",
    imagen: null
  });
  const [message, setMessage] = useState("");
  const [huellas, setHuellas] = useState([]);
  const [imagePreview, setImagePreview] = useState(null);

  useEffect(() => {
    if (role === "lector") {
      fetchHuellas();
    }
  }, [role]);

  const handleMenuChange = (newMenu) => {
    setMenu(newMenu);
    setMessage("");
  };

  const handleChange = (e) => setFormData({ ...formData, [e.target.name]: e.target.value });

  const handleFileChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFormData({ ...formData, imagen: file });
      setImagePreview(URL.createObjectURL(file));
    }
  };

  const handleAuthChange = (e) => setUser({ ...user, [e.target.name]: e.target.value });

  const register = async () => {
    try {
      await axios.post("http://localhost:5000/register", user);
      alert("✅ Usuario registrado");
      setUser({ username: "", password: "", role: "lector" });
      handleMenuChange("inicio");
    } catch {
      alert("❌ Error en el registro");
    }
  };

  const login = async () => {
    try {
      const response = await axios.post("http://localhost:5000/login", user);
      setLoggedIn(true);
      setRole(response.data.role);
      alert(`✅ Sesión iniciada como ${response.data.role}`);
    } catch {
      alert("❌ Error en el inicio de sesión");
    }
  };

  const logout = () => {
    setLoggedIn(false);
    setRole(null);
    setUser({ username: "", password: "", role: "lector" });
    setFormData({ nombre: "", apellido: "", documento: "", telefono: "", direccion: "", email: "", genero: "", fecha: "", hora: "", fingerprint: "", imagen: null });
    setImagePreview(null);
    handleMenuChange("inicio");
  };

  return (
    <div>
      <Header/>
      {menu === "register" && !loggedIn && (
        <>
          <div className="contenedor_registro">
            <h1>Registro</h1>
            <input type="text" name="username" placeholder="Usuario" value={user.username} onChange={handleAuthChange} /><br />
            <input type="password" name="password" placeholder="Contraseña" value={user.password} onChange={handleAuthChange} /><br />
            <select name="role" value={user.role} onChange={handleAuthChange}>
              <option value="admin">Administrador</option>
              <option value="lector">Lector</option>
            </select><br />
            <input type="text" name="documento" placeholder="Documento de Identidad" value={formData.documento} onChange={handleChange} /><br />
            <input type="text" name="telefono" placeholder="Teléfono" value={formData.telefono} onChange={handleChange} /><br />
            <input type="text" name="direccion" placeholder="Dirección" value={formData.direccion} onChange={handleChange} /><br />
            <input type="email" name="email" placeholder="Correo Electrónico" value={formData.email} onChange={handleChange} /><br />
            <select name="genero" value={formData.genero} onChange={handleChange}>
              <option value="">Seleccione Género</option>
              <option value="masculino">Masculino</option>
              <option value="femenino">Femenino</option>
              <option value="otro">Otro</option>
            </select><br />
            <button onClick={register}>Registrarse</button>
            <button onClick={() => handleMenuChange("inicio")}>Volver</button>
          </div>
        </>
      )}
      {message && <p>{message}</p>}
    </div>
  );
};

export default App;
