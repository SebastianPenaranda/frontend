import React, { useState } from 'react'
import "./header.css"

const Header = () => {
    /*========TOGGLE MENU=========*/
    const [Toggle, showMenu] = useState(false);
  return (
    <header className="header">
        <nav className="nav container">
            <a href="index.html" className="nav__logo">
                <img src='https://www.unicatolica.edu.co/files/unicatolica-svg.svg'/>
            </a>

            <div className={Toggle ? "nav__menu show-menu" : "nav__menu"}>
                <ul className="nav__list grid">
                    <li className="nav__item">
                        <a href="#Casa" className="nav__link active-link">
                            <ion-icon className="nav__icon" name="home-outline"></ion-icon>
                            Casa 
                        </a>
                    </li>
                    <li className="nav__item">
                        <a href="#Soporte" className="nav__link">
                            <ion-icon className="nav__icon" name="call-outline"></ion-icon>
                            Soporte
                        </a>
                    </li>
                    <li className="nav__item">
                        <a href="#Usuario" className="nav__link">
                            <ion-icon className="nav__icon" name="person-outline"></ion-icon>
                            Usuario
                        </a>
                    </li>
                </ul>

                <ion-icon className="nav__close" name="close-outline" onClick={() => showMenu(!Toggle)}></ion-icon>

            </div>

            <div className="nav__toggle" onClick={() => showMenu(!Toggle)}>
                <ion-icon name="apps-outline"></ion-icon>
            </div>
        </nav>
    </header>

  )
}

export default Header
